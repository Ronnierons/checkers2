package com.example.denys.checkersgame.activities;

import android.graphics.Color;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.denys.checkersgame.move.Move;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

public class EnterActivity extends AppCompatActivity {

    private Socket socket;

    private static PrintStream ps;
    private static DataInputStream is;
    private static final int PORT = 2222;
    private static final String SERVER_IP = "10.0.2.2";
    private static String read = null;
    private String connectTo = null;
    private int lastAction = 0;

    private static final int[][] BOARD_ID = {
            {R.id.a1, R.id.a2, R.id.a3, R.id.a4, R.id.a5, R.id.a6, R.id.a7, R.id.a8},
            {R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6, R.id.b7, R.id.b8},
            {R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6, R.id.c7, R.id.c8},
            {R.id.d1, R.id.d2, R.id.d3, R.id.d4, R.id.d5, R.id.d6, R.id.d7, R.id.d8},
            {R.id.e1, R.id.e2, R.id.e3, R.id.e4, R.id.e5, R.id.e6, R.id.e7, R.id.e8},
            {R.id.f1, R.id.f2, R.id.f3, R.id.f4, R.id.f5, R.id.f6, R.id.f7, R.id.f8},
            {R.id.g1, R.id.g2, R.id.g3, R.id.g4, R.id.g5, R.id.g6, R.id.g7, R.id.g8},
            {R.id.h1, R.id.h2, R.id.h3, R.id.h4, R.id.h5, R.id.h6, R.id.h7, R.id.h8}};
    private static final int[][] BOARD_ID_INV = {
            {R.id.h8, R.id.h7, R.id.h6, R.id.h5, R.id.h4, R.id.h3, R.id.h2, R.id.h1},
            {R.id.g8, R.id.g7, R.id.g6, R.id.g5, R.id.g4, R.id.g3, R.id.g2, R.id.g1},
            {R.id.f8, R.id.f7, R.id.f6, R.id.f5, R.id.f4, R.id.f3, R.id.f2, R.id.f1},
            {R.id.e8, R.id.e7, R.id.e6, R.id.e5, R.id.e4, R.id.e3, R.id.e2, R.id.e1},
            {R.id.d8, R.id.d7, R.id.d6, R.id.d5, R.id.d4, R.id.d3, R.id.d2, R.id.d1},
            {R.id.c8, R.id.c7, R.id.c6, R.id.c5, R.id.c4, R.id.c3, R.id.c2, R.id.c1},
            {R.id.b8, R.id.b7, R.id.b6, R.id.b5, R.id.b4, R.id.b3, R.id.b2, R.id.b1},
            {R.id.a8, R.id.a7, R.id.a6, R.id.a5, R.id.a4, R.id.a3, R.id.a2, R.id.a1}};

    private static boolean isRed;
    private static Move[] moves;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);
        new ClientThread().execute();

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;


        TableLayout tl = findViewById(R.id.board);
        for (int i = 0; i < tl.getChildCount(); i++) {
            TableRow tr = (TableRow) tl.getChildAt(i);
            for (int j = 0; j < tr.getChildCount(); j++) {
                View button = tr.getChildAt(j);
                button.getLayoutParams().width = width / 8;
                button.getLayoutParams().height = width / 8;
                button.setOnClickListener(this::clicked);
                button.setClickable(false);
            }
        }
    }

    public void createGame(View view) {
        findViewById(R.id.start_layout).setVisibility(View.GONE);
        findViewById(R.id.create_layout).setVisibility(View.VISIBLE);
    }

    public void findGame(View view) {
        new Thread(() -> ps.println("find game")).start();
    }

    public void createConfirm(View view) {
        if (connectTo == null) {
            String name = ((TextView) findViewById(R.id.name_edit_text)).getText().toString().trim();
            if (name.equals("")) {
                Toast t = Toast.makeText(getApplicationContext(), "Please, enter name", Toast.LENGTH_LONG);
                t.show();
            } else {
                isRed = true;
                if (ps != null)
                    new Thread(() -> ps.println("connect red%%" + name)).start();
            }
        } else {
            String name = ((TextView) findViewById(R.id.name_edit_text)).getText().toString().trim();
            if (name.equals("")) {
                Toast t = Toast.makeText(getApplicationContext(), "Please, enter name", Toast.LENGTH_LONG);
                t.show();
            } else {
                isRed = false;
                if (ps != null)
                    new Thread(() -> ps.println("connect black%%" + name + "%%" + connectTo)).start();
            }
        }
    }

    @Override
    public void onBackPressed() {
    }

    private class ClientThread extends AsyncTask<Void, String, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                publishProgress("EXCEPTION1");
                InetAddress ip = InetAddress.getByName(SERVER_IP);
                publishProgress(ip.getHostAddress());
                socket = new Socket(ip, PORT);
                publishProgress("EXCEPTION4");
                ps = new PrintStream(socket.getOutputStream());
                is = new DataInputStream(socket.getInputStream());
                while (true) {
                    String line = is.readLine();
                    if (line != null)
                        publishProgress(line);
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
                publishProgress("EXCEPTION2");
            } catch (IOException e) {
                e.printStackTrace();
                publishProgress("EXCEPTION3 " + e.getMessage());
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            read = values[0];
            Log.d("Read from net", read);
            if (read.equals("start red")) {
                openGame();
            } else if (read.equals("EXCEPTION1")) {
                Toast.makeText(getApplicationContext(), "Wait for next message about connection to " + SERVER_IP + " on this screen", Toast.LENGTH_LONG).show();
            } else if (read.equals("EXCEPTION2")) {
                Toast.makeText(getApplicationContext(), "Can't connect to " + SERVER_IP, Toast.LENGTH_LONG).show();
            } else if (read.startsWith("EXCEPTION3")) {
                Toast.makeText(getApplicationContext(), read, Toast.LENGTH_LONG).show();
            } else if (read.equals("EXCEPTION4")) {
                Toast.makeText(getApplicationContext(), "Connected to " + SERVER_IP + ". Now you can start the game", Toast.LENGTH_LONG).show();
            } else if (read.equals("start black")) {
                openGame();
            } else if (read.equals("no games")) {
                Toast t = Toast.makeText(getApplicationContext(), "No active games", Toast.LENGTH_LONG);
                t.show();
            } else if (read.startsWith("listOfGames:")) {
                findViewById(R.id.start_layout).setVisibility(View.GONE);
                findViewById(R.id.find_layout).setVisibility(View.VISIBLE);
                LinearLayout listOfGames = findViewById(R.id.list_of_games);
                for (String s : read.split(":")[1].split(",")) {
                    if (!s.equals("")) {
                        TextView tv = new TextView(getApplicationContext());
                        tv.setText(s);
                        tv.setTextSize(25);
                        tv.setBackground(getDrawable(R.drawable.games_background));
                        tv.setTextColor(Color.DKGRAY);
                        tv.setGravity(Gravity.CENTER);
                        tv.setOnClickListener(EnterActivity.this::selectGame);
                        listOfGames.addView(tv);
                    }
                }
            } else if (read.startsWith("Connecting to game:")) {
                Toast t = Toast.makeText(getApplicationContext(), read.split(":")[1] + " connected to game", Toast.LENGTH_LONG);
                t.show();
            } else if (read.startsWith("board%%")) {
                setImages(read.split("%%")[1]);
            } else if (read.startsWith("moves%%")) {
                setMoves(read.split("%%")[1]);
            } else if (read.equals("selected")) {
                lastAction = 1;
            } else if (read.equals("moved")) {
                lastAction = 2;
                ps.println("get board");
            } else if (read.startsWith("jump to")) {
                lastAction = 1;
                setMoves(read.split("%%")[1]);
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        ImageButton ib;
                        if (isRed) {
                            ib = findViewById(BOARD_ID[i][j]);
                        } else {
                            ib = findViewById(BOARD_ID_INV[i][j]);
                        }
                        if (ib.isClickable()) {
                            ib.setClickable(false);
                            ib.setBackgroundColor(Color.WHITE);
                        }
                        for (Move m : moves) {
                            if (m.getToRow() == i && m.getToCol() == j) {
                                ib.setBackground(getDrawable(R.drawable.white_button_border_red));
                                ib.setClickable(true);
                            }
                        }
                    }
                }
            } else if (read.endsWith("wins")) {
                Toast t = Toast.makeText(getApplicationContext(), read, Toast.LENGTH_LONG);
                t.show();
                findViewById(R.id.find_layout).setVisibility(View.GONE);
                findViewById(R.id.create_layout).setVisibility(View.GONE);
                findViewById(R.id.game_layout).setVisibility(View.GONE);
                findViewById(R.id.start_layout).setVisibility(View.GONE);
                findViewById(R.id.end_game).setVisibility(View.VISIBLE);
            }
        }
    }

    public void end(View view) {
        new Thread(() -> {
            ps.close();
            try {
                is.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

    private void setMoves(String in) {
        String[] movesArr = in.split(";");
        moves = new Move[movesArr.length];
        for (int i = 0; i < movesArr.length; i++) {
            String move = movesArr[i];
            int fromRow = Integer.parseInt(move.split(",")[0]);
            int fromCol = Integer.parseInt(move.split(",")[1]);
            int toRow = Integer.parseInt(move.split(",")[2]);
            int toCol = Integer.parseInt(move.split(",")[3]);
            if (isRed) {
                ImageButton ib = findViewById(BOARD_ID[fromRow][fromCol]);
                ib.setClickable(true);
                ib.setBackground(getDrawable(R.drawable.white_button_border_red));
            } else {
                ImageButton ib = findViewById(BOARD_ID_INV[fromRow][fromCol]);
                ib.setClickable(true);
                ib.setBackground(getDrawable(R.drawable.white_button_border_red));
            }
            moves[i] = new Move(fromRow, fromCol, toRow, toCol);
        }
    }

    protected void selectGame(View view) {
        connectTo = ((TextView) view).getText().toString();
        findViewById(R.id.find_layout).setVisibility(View.GONE);
        findViewById(R.id.create_layout).setVisibility(View.VISIBLE);
    }

    public void openGame() {
        findViewById(R.id.find_layout).setVisibility(View.GONE);
        findViewById(R.id.create_layout).setVisibility(View.GONE);
        findViewById(R.id.start_layout).setVisibility(View.GONE);
        findViewById(R.id.game_layout).setVisibility(View.VISIBLE);
        ps.println("get board");
    }

    public void setImages(String board) {
        String[] cells = board.split(",");
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (isRed) {
                    switch (cells[i * 8 + j]) {
                        case "0":
                            ((ImageButton) findViewById(BOARD_ID[i][j])).setImageDrawable(null);
                            break;
                        case "1":
                            ((ImageButton) findViewById(BOARD_ID[i][j])).setImageDrawable(getDrawable(R.drawable.red_checker));
                            break;
                        case "2":
                            ((ImageButton) findViewById(BOARD_ID[i][j])).setImageDrawable(getDrawable(R.drawable.red_checker_king));
                            break;
                        case "3":
                            ((ImageButton) findViewById(BOARD_ID[i][j])).setImageDrawable(getDrawable(R.drawable.grey_checker));
                            break;
                        case "4":
                            ((ImageButton) findViewById(BOARD_ID[i][j])).setImageDrawable(getDrawable(R.drawable.grey_checker_king));
                            break;
                    }
                } else {
                    switch (cells[i * 8 + j]) {
                        case "0":
                            ((ImageButton) findViewById(BOARD_ID_INV[i][j])).setImageDrawable(null);
                            break;
                        case "1":
                            ((ImageButton) findViewById(BOARD_ID_INV[i][j])).setImageDrawable(getDrawable(R.drawable.red_checker));
                            break;
                        case "2":
                            ((ImageButton) findViewById(BOARD_ID_INV[i][j])).setImageDrawable(getDrawable(R.drawable.red_checker_king));
                            break;
                        case "3":
                            ((ImageButton) findViewById(BOARD_ID_INV[i][j])).setImageDrawable(getDrawable(R.drawable.grey_checker));
                            break;
                        case "4":
                            ((ImageButton) findViewById(BOARD_ID_INV[i][j])).setImageDrawable(getDrawable(R.drawable.grey_checker_king));
                            break;
                    }
                }
            }
        }
    }

    protected void clicked(View view) {
        int[] coords = findCoords(view.getId());
        Log.d("coords", Arrays.toString(coords));
        if (lastAction != 1) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    ImageButton ib;
                    if (isRed) {
                        ib = findViewById(BOARD_ID[i][j]);
                    } else {
                        ib = findViewById(BOARD_ID_INV[i][j]);
                    }
                    if (ib.isClickable()) {
                        ib.setClickable(false);
                        ib.setBackgroundColor(Color.WHITE);
                    }
                    for (Move m : moves) {
                        if ((m.getFromRow() == coords[0] && m.getFromCol() == coords[1]) && (m.getToRow() == i && m.getToCol() == j)) {
                            Log.d("Coords to", ib.getResources().getResourceName(ib.getId()));
                            ib.setBackground(getDrawable(R.drawable.white_button_border_red));
                            ib.setClickable(true);
                            Log.d("asd", ib.isClickable() + "");
                        }
                    }
                }
            }
            if (isRed)
                findViewById(BOARD_ID[coords[0]][coords[1]]).setBackground(getDrawable(R.drawable.white_button_border_green));
            else
                findViewById(BOARD_ID_INV[coords[0]][coords[1]]).setBackground(getDrawable(R.drawable.white_button_border_green));
        } else {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if ((i + j) % 2 == 0) {
                        ImageButton ib = findViewById(BOARD_ID[i][j]);
                        ib.setBackgroundColor(Color.WHITE);
                        ib.setClickable(false);
                    }
                }
            }
        }
        if (ps != null) {
            try {
                new Thread(() -> {
                    ps.println("moving%%" + coords[0] + coords[1]);
                    ps.flush();
                }).start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private int[] findCoords(int id) {
        int[] coords = new int[2];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (isRed) {
                    if (BOARD_ID[i][j] == id) {
                        coords[0] = i;
                        coords[1] = j;
                        return coords;
                    }
                } else {
                    if (BOARD_ID_INV[i][j] == id) {
                        coords[0] = i;
                        coords[1] = j;
                        return coords;
                    }
                }
            }
        }
        return coords;
    }


    public static String getRead() {
        return read;
    }

    public static void setRead(String read) {
        EnterActivity.read = read;
    }
}

