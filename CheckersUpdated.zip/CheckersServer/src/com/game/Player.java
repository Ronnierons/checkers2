package com.game;

import java.io.PrintStream;

public class Player {
    
    private String name;
    private int color;
    private final PrintStream os;

    public Player(String name, int color, PrintStream os) {
        this.name = name;
        this.color = color;
        this.os = os;
    }

    public String getName() {
        return name;
    }

    public PrintStream getOs() {
        return os;
    }

    public int getColor() {
        return color;
    }
    
}
