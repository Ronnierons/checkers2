package com.game;

public class Checkers {

    private Player redPlayer;
    private Player blackPlayer;
    private boolean started;
    private CheckersData board;
    private int currentPlayer;
    private int selectedRow, selectedCol;
    private CheckersMove[] legalMoves;

    public Checkers(Player red) {
        this.redPlayer = red;
        this.started = false;
        currentPlayer = CheckersData.RED;
        board = new CheckersData();
        doNewGame();
    } // end constructor 

    public void connectBlack(Player player) {
        this.blackPlayer = player;
        this.started = true;
    }

    /**
     * Start a new game
     */
    private void doNewGame() {
        board.setUpGame();   // Set up the pieces.
        currentPlayer = CheckersData.RED;   // RED moves first.
        legalMoves = board.getLegalMoves(CheckersData.RED);  // Get RED's legal moves.
    }

    /**
     * This is called by mousePressed() when a player clicks on the square in
     * the specified row and col. It has already been checked that a game is, in
     * fact, in progress.
     */
    String doSelectedSquare(int row, int col) {

        /* If the player clicked on one of the pieces that the player
          can move, mark this row and col as selected and return.  (This
          might change a previous selection.)  Reset the message, in
          case it was previously displaying an error message. */
        for (int i = 0; i < legalMoves.length; i++) {
            if (legalMoves[i].getFromRow() == row && legalMoves[i].getFromCol() == col) {
                selectedRow = row;
                selectedCol = col;
                return "selected";
            }
        }

        /* If the user clicked on a squre where the selected piece can be
          legally moved, then make the move and return. */
        for (int i = 0; i < legalMoves.length; i++) {
            if (legalMoves[i].getFromRow() == selectedRow && legalMoves[i].getFromCol() == selectedCol
                    && legalMoves[i].getToRow() == row && legalMoves[i].getToCol() == col) {
                return doMakeMove(legalMoves[i]);

            }
        }
        return null;

    }  // end doClickSquare()

    /**
     * This is called when the current player has chosen the specified move.
     * Make the move, and then either end or continue the game appropriately.
     */
    String doMakeMove(CheckersMove move) {

        board.makeMove(move);

        /* If the move was a jump, it's possible that the player has another
          jump.  Check for legal jumps starting from the square that the player
          just moved to.  If there are any, the player must jump.  The same
          player continues moving.
         */
        if (move.isJump()) {
            legalMoves = board.getLegalJumpsFrom(currentPlayer, move.getToRow(), move.getToCol());
            if (legalMoves != null) {
                //message.setText("RED:  You must continue jumping.");
                selectedRow = move.getToRow();  // Since only one piece can be moved, select it.
                selectedCol = move.getToCol();
                return "jumping";
            }
        }

        /* The current player's turn is ended, so change to the other player.
          Get that player's legal moves.  If the player has no legal moves,
          then the game ends. */
        if (currentPlayer == CheckersData.RED) {
            currentPlayer = CheckersData.BLACK;
            legalMoves = board.getLegalMoves(currentPlayer);
            if (legalMoves == null) {
                selectedRow = -1;
                return "red wins";
            } else {
                selectedRow = -1;
                return "black moves";
            }
        } else {
            currentPlayer = CheckersData.RED;
            legalMoves = board.getLegalMoves(currentPlayer);
            if (legalMoves == null) {
                selectedRow = -1;
                return "black wins";
            } else {
                selectedRow = -1;
                return "red moves";
            }
        }

    }  // end doMakeMove();

    public Player getRedPlayer() {
        return redPlayer;
    }

    public Player getBlackPlayer() {
        return blackPlayer;
    }

    public boolean isStarted() {
        return started;
    }
    
    public String getBoardAsString(){
        return board.getBoardAsString();
    }
    
} // end class Checkers
