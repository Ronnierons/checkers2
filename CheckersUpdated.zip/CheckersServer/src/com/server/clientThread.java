package com.server;

import com.game.Checkers;
import com.game.CheckersData;
import com.game.Player;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

// For every client's connection we call this class
public class clientThread extends Thread {

    private String clientName = null;
    private DataInputStream is = null;
    private PrintStream os = null;
    private Socket clientSocket = null;
    private final clientThread[] threads;
    private final Checkers[] games;
    private int maxClientsCount;
    private Player player;
    private Checkers currentGame;

    public clientThread(Socket clientSocket, clientThread[] threads, Checkers[] games) {
        this.clientSocket = clientSocket;
        this.threads = threads;
        this.games = games;
        maxClientsCount = threads.length;
    }

    public void run() {
        int maxClientsCount = this.maxClientsCount;
        clientThread[] threads = this.threads;

        try {
            /*
             * Create input and output streams for this client.
             */
            is = new DataInputStream(clientSocket.getInputStream());
            os = new PrintStream(clientSocket.getOutputStream());

            /* Start the conversation. */
            while (true) {
                if (!clientSocket.isConnected()) {
                    System.out.println("disconnected");
                    break;
                }
                String line = is.readLine();
                if (line != null) {
                    System.out.println(line);
                    if (line.startsWith("connect red%%")) {
                        int i;
                        for (i = 0; i < games.length; i++) {
                            if (games[i] == null) {
                                this.player = new Player(line.split("%%")[1], CheckersData.RED, os);
                                currentGame = new Checkers(player);
                                games[i] = currentGame;
                                os.println("start red");
                                os.println("board%%"+currentGame.getBoardAsString());
                                break;
                            }
                        }
                        System.out.println(i);
                        if (i == games.length) {
                            os.println("Can't create game");
                            break;
                        }
                    } else if (line.equals("find game")) {
                        String avGames = "listOfGames:";
                        for (Checkers game : games) {
                            if (game != null && !game.isStarted()) {
                                avGames += game.getRedPlayer().getName() + ",";
                            }
                        }
                        if (avGames.equals("listOfGames:")) {
                            avGames = "no games";
                        }
                        os.println(avGames);
                    } else if(line.startsWith("connect black%%")){
                        for (int i = 0; i < games.length; i++) {
                            if (games[i] != null && games[i].getRedPlayer().getName().equals(line.split("%%")[2])) {
                                this.player = new Player(line.split("%%")[1],CheckersData.BLACK,os);
                                games[i].connectBlack(player);
                                currentGame = games[i];
                                os.println("start black");
                                games[i].getRedPlayer().getOs().println("Connecting to game:"+player.getName());
                                break;
                            }
                        }
                    }
                    os.flush();
                } else {
                    break;
                }
            }
            /*
             * Clean up. Set the current thread variable to null so that a new client
             * could be accepted by the server.
             */
            synchronized (this) {
                for (int i = 0; i < maxClientsCount; i++) {
                    if (threads[i] == this) {
                        threads[i] = null;
                        break;
                    }
                }
                for(int i = 0; i < games.length; i++){
                    if(games[i].getBlackPlayer() == player || games[i].getRedPlayer() == player){
                        games[i] = null;
                        System.out.println("game closed");
                        break;
                    }
                }
            }
            /*
             * Close the output stream, close the input stream, close the socket.
             */
            is.close();
            os.close();
            clientSocket.close();
            System.out.println("Closed");
        } catch (IOException e) {
        }
    }
}
